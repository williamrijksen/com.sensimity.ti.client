(function(f){if(typeof exports==="object"&&typeof module!=="undefined"){module.exports=f()}else if(typeof define==="function"&&define.amd){define([],f)}else{var g;if(typeof window!=="undefined"){g=window}else if(typeof global!=="undefined"){g=global}else if(typeof self!=="undefined"){g=self}else{g=this}g=(g.com||(g.com = {}));g=(g.sensimity||(g.sensimity = {}));g=(g.ti||(g.ti = {}));g.client = f()}})(function(){var define,module,exports;return (function e(t,n,r){function o(i,u){if(!n[i]){if(!t[i]){var a=typeof require=="function"&&require;if(!u&&a)return a.length===2?a(i,!0):a(i);if(s&&s.length===2)return s(i,!0);if(s)return s(i);var f=new Error("Cannot find module '"+i+"'");throw f.code="MODULE_NOT_FOUND",f}var l=n[i]={exports:{}};t[i][0].call(l.exports,function(e){var n=t[i][1][e];return o(n?n:e)},l,l.exports,e,t,n,r)}return n[i].exports}var i=Array.prototype.slice;Function.prototype.bind||Object.defineProperty(Function.prototype,"bind",{enumerable:!1,configurable:!0,writable:!0,value:function(e){function r(){return t.apply(this instanceof r&&e?this:e,n.concat(i.call(arguments)))}if(typeof this!="function")throw new TypeError("Function.prototype.bind - what is trying to be bound is not callable");var t=this,n=i.call(arguments,1);return r.prototype=Object.create(t.prototype),r.prototype.contructor=r,r}});var s=typeof require=="function"&&require;for(var u=0;u<r.length;u++)o(r[u]);return o})({1:[function(require,module,exports){
'use strict';

var sensimity = require('./lib/sensimity');

module.exports = sensimity;

},{"./lib/sensimity":21}],2:[function(require,module,exports){
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _alloy = require("alloy");

var _alloy2 = _interopRequireDefault(_alloy);

var _underscore = require("alloy/underscore");

var _backbone = require("alloy/backbone");

var _backbone2 = _interopRequireDefault(_backbone);

var _reste = require("reste");

var _reste2 = _interopRequireDefault(_reste);

var _oauth = require("./oauth2");

var _oauth2 = _interopRequireDefault(_oauth);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/* Compatibility for Ti standalone (without Alloy) */
if (typeof OS_ANDROID === "undefined") {
    var _OS_ANDROID = Ti.Platform.name === "android";
    var OS_IOS = Ti.Platform.name === "iPhone OS";
}

var token = void 0;
var expires = void 0;
var url = "https://api.sensimity.com/";
var api = new _reste2.default();

if (_alloy2.default.CFG.sensimity.url) {
    url = _alloy2.default.CFG.sensimity.url;
}

function setApiConfig() {
    var config = {
        debug: false, // allows logging to console of ::REST:: messages
        autoValidateParams: false, // set to true to throw errors if <param> url properties are not passed
        timeout: 10000,
        url: url,
        requestHeaders: {
            "Accept": "application/vnd.sensimity.v1+json",
            "Content-Type": "application/vnd.sensimity.v1+json",
            "Authorization": "Bearer " + _oauth2.default.getAccess().token
        },
        methods: [{
            name: "getNetworks",
            get: "network"
        }, {
            name: "getBeacons",
            get: "network/<networkId>/beacon"
        }, {
            name: "getBusinessRules",
            get: "network/<networkId>/business-rule?beacon=<beaconId>"
        }, {
            name: "getSingleBusinessRule",
            get: "network/<networkId>/business-rule/<businessRuleId>"
        }, {
            name: "sendScanResults",
            post: "scan-results"
        }],
        onError: function onError(e) {
            Ti.API.info("There was an error accessing the API > " + JSON.stringify(e));
        },
        onLoad: function onLoad(e, callback) {
            callback(e);
        }
    };

    api.config(config);
}

function getNetworks(callback) {
    _oauth2.default.init(function () {
        setApiConfig();
        api.getNetworks(function (beacons) {
            return callback(beacons);
        });
    });
}

function getBeacons(networkId, callback) {
    _oauth2.default.init(function () {
        setApiConfig();
        api.getBeacons({
            networkId: networkId
        }, function (response) {
            return callback(response);
        });
    });
}

function getBusinessRules(networkId, beaconId, callback) {
    _oauth2.default.init(function () {
        setApiConfig();
        api.getBusinessRules({
            networkId: networkId,
            beaconId: beaconId
        }, function (response) {
            return callback(response);
        });
    });
}

function getSingleBusinessRule(networkId, businessRuleId, callback) {
    _oauth2.default.init(function () {
        setApiConfig();
        api.getSingleBusinessRule({
            networkId: networkId,
            businessRuleId: businessRuleId
        }, function (response) {
            return callback(response);
        });
    });
}

function sendScanResults(body, callback) {
    _oauth2.default.init(function () {
        setApiConfig();
        api.sendScanResults({
            body: body
        }, callback);
    });
}

exports.default = {
    getNetworks: getNetworks,
    getBeacons: getBeacons,
    sendScanResults: sendScanResults,
    getSingleBusinessRule: getSingleBusinessRule,
    getBusinessRules: getBusinessRules
};
},{"./oauth2":3,"alloy":undefined,"alloy/backbone":undefined,"alloy/underscore":undefined,"reste":undefined}],3:[function(require,module,exports){
'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.getAccess = exports.init = undefined;

var _alloy = require('alloy');

var _alloy2 = _interopRequireDefault(_alloy);

var _underscore = require('alloy/underscore');

var _backbone = require('alloy/backbone');

var _backbone2 = _interopRequireDefault(_backbone);

var _reste = require('reste');

var _reste2 = _interopRequireDefault(_reste);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var basicAuthHeader = Ti.Utils.base64encode(_alloy2.default.CFG.sensimity.basicHeaderAuthUsername + ':' + _alloy2.default.CFG.sensimity.basicHeaderAuthPassword).toString();
var api = new _reste2.default();

var expires = void 0;
var url = "https://api.sensimity.com/";
var access = {};

if (_alloy2.default.CFG.sensimity.url) {
    url = _alloy2.default.CFG.sensimity.url;
}

api.config({
    debug: false, // allows logging to console of ::REST:: messages
    autoValidateParams: false, // set to true to throw errors if <param> url properties are not passed
    timeout: 10000,
    url: url,
    requestHeaders: {
        "Accept": "application/vnd.sensimity.v1+json",
        "Content-Type": "application/vnd.sensimity.v1+json",
        "Authorization": 'Basic ' + basicAuthHeader
    },
    methods: [{
        name: 'oauth',
        post: 'oauth'
    }],
    onLoad: function onLoad(e, callback) {
        callback(e);
    }
});

/**
 * Initialize the oauthClient, first retrieve the oAuth refreshtoken and trigger the callback.
 * @param Callback you can send a POST or GET request after fetching a new oAuth token
 */
function init(clientReady) {
    // Check the refreshtoken is expired, if expired retrieve a new accesstoken
    if (isAccessTokenExpired()) {
        refreshAccessToken(clientReady);
        return;
    }

    // Set callback
    clientReady();
}

exports.init = init;
exports.getAccess = getAccess;

/**
 * Private functions
 */

// Check the expiredate is undefined or is expired

function isAccessTokenExpired() {
    getAccess();
    if (_underscore._.isEmpty(access)) {
        return true;
    }

    if (now() > access.expires) {
        return true;
    }

    return false;
}

// Refresh the accesstoken by refreshtoken or password
function refreshAccessToken(successCallback) {
    var body = {};

    if (isRefreshTokenAvailable()) {
        var auth = getAuth();
        body.refresh_token = auth.refreshToken;
        body.grant_type = 'refresh_token';
    } else {
        body.username = _alloy2.default.CFG.sensimity.username;
        body.password = _alloy2.default.CFG.sensimity.password;
        body.grant_type = 'password';
    }

    api.oauth({
        body: body
    }, function (response) {
        if (!_underscore._.isUndefined(response.status)) {
            switch (response.status) {
                case 400:
                    if (!_underscore._.isUndefined(response.title) && response.title === 'invalid_grant') {
                        setAuth({});
                        refreshAccessToken(successCallback);
                    }
                    return;
                    break;
                default:
                    Ti.API.info("Response status is set");
                    break;
            }
        }

        saveTokens(response);
        successCallback();
    });
}

// Save the obtained token
function saveTokens(response) {
    var auth = getAuth();
    // Save the retrieved accesstoken
    auth.accessToken = response.access_token;
    if (response.refresh_token) {
        // If also an refreshtoken is retrieved, save the refreshtoken
        auth.refreshToken = response.refresh_token;
    }
    // save the time when the accesstoken expires
    auth.expires = now() + response.expires_in;
    setAuth(auth);
}

// check refreshtoken is earlier retrieved
function isRefreshTokenAvailable() {
    var auth = getAuth();
    return !_underscore._.isEmpty(auth) && !_underscore._.isUndefined(auth.refreshToken);
}

// Get now
function now() {
    return Math.floor(new Date().getTime() / 1000);
}

// Get access from memory or storage
function getAccess() {
    if (_underscore._.isEmpty(access)) {
        var auth = getAuth();
        if (_underscore._.isEmpty(auth) || _underscore._.isNaN(auth.expires)) {
            return {};
        }
        access = {
            expires: auth.expires,
            token: auth.accessToken
        };
    }

    return access;
}

// Get oauth credentials from storage
function getAuth() {
    return Ti.App.Properties.getObject('sensimity_oauth', {});
}

// Set oauth credentials in storage and update the access variable in memory
function setAuth(object) {
    if (_underscore._.isEmpty(object)) {
        access = {};
    } else {
        access = {
            expires: object.expires,
            token: object.accessToken
        };
    }
    Ti.App.Properties.setObject('sensimity_oauth', object);
}
},{"alloy":undefined,"alloy/backbone":undefined,"alloy/underscore":undefined,"reste":undefined}],4:[function(require,module,exports){
'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _alloy = require('alloy');

var _alloy2 = _interopRequireDefault(_alloy);

var _underscore = require('alloy/underscore');

var _backbone = require('alloy/backbone');

var _backbone2 = _interopRequireDefault(_backbone);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

// Clone
exports.default = _underscore._.clone(_backbone2.default.Events);
},{"alloy":undefined,"alloy/backbone":undefined,"alloy/underscore":undefined}],5:[function(require,module,exports){
'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _alloy = require('alloy');

var _alloy2 = _interopRequireDefault(_alloy);

var _underscore = require('alloy/underscore');

var _backbone = require('alloy/backbone');

var _backbone2 = _interopRequireDefault(_backbone);

var _businessRule = require('./../service/businessRule');

var _businessRule2 = _interopRequireDefault(_businessRule);

var _knownBeacons = require('./../service/knownBeacons');

var _knownBeacons2 = _interopRequireDefault(_knownBeacons);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

// Found beacons is used to handle the moving towards and moving away from business rules
var foundBeacons = void 0;

var typeOfAvailableBusinessRules = { // Types of available Business rules
    far: 'far',
    close: 'close',
    immediate: 'immediate',
    movingTowards: 'moving_towards',
    movingAwayFrom: 'moving_away_from'
};

var proximities = {
    far: 'far',
    close: 'near',
    immediate: 'immediate'
};

/**
 * Public functions
 */

/*****
 * Initialize the handler and set the notify and knownbeaconservice
 */
function init() {
    foundBeacons = [];
}

/****
 * This function must be called when the beaconscanner founds a beacon. It checks beacon exists in the system and search for the appropiate business rule(s).
 * @param mappedBeacon Mapped beacon is a found beacon in the base scanner
 */
function handle(mappedBeacon) {
    var knownBeacon = _knownBeacons2.default.findKnownBeacon(mappedBeacon.UUID, mappedBeacon.major, mappedBeacon.minor);
    // If beacon = unknown, do nothing
    if (_underscore._.isEmpty(knownBeacon)) {}

    // Trigger a 'beacon found' event
    handleBeacon(mappedBeacon, knownBeacon);

    // Find appropiate business rules
    var businessRules = _businessRule2.default.getBusinessRules(knownBeacon);

    // Handle every businessrule
    businessRules.forEach(function (businessRule) {
        handleBusinessRule(businessRule, mappedBeacon, knownBeacon);
    });

    // add found beacon with proximity and beacon_id
    addFoundBeacon(mappedBeacon.proximity, knownBeacon.get('beacon_id'));
}

exports.default = { init: init, handle: handle };

/**
 * Private functions
 */

/****
 * Handle and checks beaconproximity and businessrule are the same. If businessrule is active, trigger the dispatcher to use this businessrule in the app
 * @param businessRule
 * @param beacon found Beacon in basescanner
 * @param knownBeacon knownBeacon from local database
 */

function handleBusinessRule(businessRule, beacon, knownBeacon) {
    var businessRuleType = businessRule.get('type');
    var businessRuleTriggerItem = {
        beacon: beacon,
        businessRule: businessRule.toJSON(),
        knownBeacon: knownBeacon.toJSON()
    };

    if (businessRuleType === typeOfAvailableBusinessRules.far && beacon.proximity === proximities.far) {
        _alloy2.default.Globals.sensimityEvent.trigger('sensimity:businessrule', businessRuleTriggerItem);
        Ti.App.fireEvent('sensimity:businessrule', businessRuleTriggerItem);
    }

    if (businessRuleType === typeOfAvailableBusinessRules.close && beacon.proximity === proximities.close) {
        _alloy2.default.Globals.sensimityEvent.trigger('sensimity:businessrule', businessRuleTriggerItem);
        Ti.App.fireEvent('sensimity:businessrule', businessRuleTriggerItem);
    }

    if (businessRuleType === typeOfAvailableBusinessRules.immediate && beacon.proximity === proximities.immediate) {
        _alloy2.default.Globals.sensimityEvent.trigger('sensimity:businessrule', businessRuleTriggerItem);
        Ti.App.fireEvent('sensimity:businessrule', businessRuleTriggerItem);
    }

    if (businessRuleType === typeOfAvailableBusinessRules.movingTowards && checkMovingTowards(beacon.proximity, knownBeacon.get('beacon_id'))) {
        _alloy2.default.Globals.sensimityEvent.trigger('sensimity:businessrule', businessRuleTriggerItem);
        Ti.App.fireEvent('sensimity:businessrule', businessRuleTriggerItem);
    }

    if (businessRuleType === typeOfAvailableBusinessRules.movingAwayFrom && checkMovingAwayFrom(beacon.proximity, knownBeacon.get('beacon_id'))) {
        _alloy2.default.Globals.sensimityEvent.trigger('sensimity:businessrule', businessRuleTriggerItem);
        Ti.App.fireEvent('sensimity:businessrule', businessRuleTriggerItem);
    }
}

/**
 * Handle a beacon if no businessrule is set for current
 * @param beacon
 * @param knownBeacon
 */
function handleBeacon(beacon, knownBeacon) {
    var eventItem = {
        beacon: beacon,
        knownBeacon: knownBeacon.toJSON()
    };
    _alloy2.default.Globals.sensimityEvent.trigger('sensimity:beacon', eventItem);
    Ti.App.fireEvent('sensimity:beacon', eventItem);
}

/**
 * Add a found beacon to check moving towards or moving away from
 * @param proximity proximity value to check compare the distance
 * @param beaconId beacon identifier
 */
function addFoundBeacon(proximity, beaconId) {
    foundBeacons = _underscore._.without(foundBeacons, _underscore._.findWhere(foundBeacons, {
        beaconId: beaconId
    }));
    foundBeacons.push({
        beaconId: beaconId,
        proximity: proximity
    });
}

// Check the proximity of previous beacon has more distance than the new proximity
function checkMovingTowards(proximity, beaconId) {
    var lastFoundBeacon = _underscore._.findWhere(foundBeacons, {
        beaconId: beaconId,
        proximity: proximities.close
    });
    return !_underscore._.isEmpty(lastFoundBeacon) && proximity === proximities.close || proximity === proximities.immediate;
}

// Check the proximity of previous beacon has less distance than the new proximity
function checkMovingAwayFrom(proximity, beaconId) {
    var lastFoundImmediateBeacon = _underscore._.findWhere(foundBeacons, {
        beaconId: beaconId,
        proximity: proximities.close
    });
    var lastFoundNearBeacon = _underscore._.findWhere(foundBeacons, {
        beaconId: beaconId,
        proximity: proximities.immediate
    });
    return (!_underscore._.isEmpty(lastFoundNearBeacon) || !_underscore._.isEmpty(lastFoundImmediateBeacon)) && proximity === proximities.far;
}
},{"./../service/businessRule":24,"./../service/knownBeacons":25,"alloy":undefined,"alloy/backbone":undefined,"alloy/underscore":undefined}],6:[function(require,module,exports){
'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.map = undefined;

var _alloy = require('alloy');

var _alloy2 = _interopRequireDefault(_alloy);

var _underscore = require('alloy/underscore');

var _backbone = require('alloy/backbone');

var _backbone2 = _interopRequireDefault(_backbone);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/* jshint ignore:end */

/**
 * Public functions
 */

/**
 * A mapping function make the beaconinfo retrieved with the drtech beaconscanner, general
 * @param beaconRaw The beacon retrieved from the beuckman
 * @returns {{UUID: string, major: Number, minor: Number, rssi: Number, accuracy: Number, proximity: String }}
 */
function map(beaconRaw) {
    return {
        UUID: beaconRaw.uuid.toUpperCase(),
        major: parseInt(beaconRaw.major),
        minor: parseInt(beaconRaw.minor),
        rssi: parseInt(beaconRaw.rssi, 10),
        accuracy: beaconRaw.accuracy,
        proximity: beaconRaw.proximity
    };
}

exports.map = map;
},{"alloy":undefined,"alloy/backbone":undefined,"alloy/underscore":undefined}],7:[function(require,module,exports){
'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.map = undefined;

var _alloy = require('alloy');

var _alloy2 = _interopRequireDefault(_alloy);

var _underscore = require('alloy/underscore');

var _backbone = require('alloy/backbone');

var _backbone2 = _interopRequireDefault(_backbone);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/* jshint ignore:end */

/**
 * Create a beaconregion from a knownbeacon used by the altbeaconscanner
 * @param knownBeacon A knownbeacon
 * @returns {{uuid: String, identifier: String}}
 */
function map(knownBeacon) {
    return {
        uuid: knownBeacon.get('UUID'),
        identifier: knownBeacon.get('beacon_id')
    };
}

exports.map = map;
},{"alloy":undefined,"alloy/backbone":undefined,"alloy/underscore":undefined}],8:[function(require,module,exports){
arguments[4][7][0].apply(exports,arguments)
},{"alloy":undefined,"alloy/backbone":undefined,"alloy/underscore":undefined,"dup":7}],9:[function(require,module,exports){
'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.map = undefined;

var _alloy = require('alloy');

var _alloy2 = _interopRequireDefault(_alloy);

var _underscore = require('alloy/underscore');

var _backbone = require('alloy/backbone');

var _backbone2 = _interopRequireDefault(_backbone);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/* jshint ignore:end */

/**
 * Public functions
 */

/**
 * A mapping function make the beaconinfo retrieved with the beuckman beaconscanner, general
 * @param beaconRaw The beacon retrieved from the beuckman
 * @returns {{UUID: string, major: Number, minor: Number, rssi: Number, accuracy: Number, proximity: String }}
 */
function map(beaconRaw) {
    return {
        UUID: beaconRaw.uuid.toUpperCase(),
        major: parseInt(beaconRaw.major),
        minor: parseInt(beaconRaw.minor),
        rssi: parseInt(beaconRaw.rssi),
        accuracy: beaconRaw.accuracy,
        proximity: beaconRaw.proximity
    };
}

exports.map = map;
},{"alloy":undefined,"alloy/backbone":undefined,"alloy/underscore":undefined}],10:[function(require,module,exports){
'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.map = undefined;

var _alloy = require('alloy');

var _alloy2 = _interopRequireDefault(_alloy);

var _underscore = require('alloy/underscore');

var _backbone = require('alloy/backbone');

var _backbone2 = _interopRequireDefault(_backbone);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/* jshint ignore:end */

/**
 * Create a beaconregion from a knownbeacon used by the beuckmanscanner
 * @param knownBeacon A knownbeacon
 * @returns {{uuid: String, identifier: String}}
 */
function map(knownBeacon) {
    return {
        uuid: knownBeacon.get('UUID'),
        identifier: knownBeacon.get('beacon_id')
    };
}

exports.map = map;
},{"alloy":undefined,"alloy/backbone":undefined,"alloy/underscore":undefined}],11:[function(require,module,exports){
arguments[4][10][0].apply(exports,arguments)
},{"alloy":undefined,"alloy/backbone":undefined,"alloy/underscore":undefined,"dup":10}],12:[function(require,module,exports){
'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.map = undefined;

var _alloy = require('alloy');

var _alloy2 = _interopRequireDefault(_alloy);

var _underscore = require('alloy/underscore');

var _backbone = require('alloy/backbone');

var _backbone2 = _interopRequireDefault(_backbone);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/* jshint ignore:end */

/**
 * Public functions
 */

function map(geofenceRegion) {
    var beaconRaw = geofenceRegion.identifier.split('|');

    return {
        UUID: beaconRaw[1].toUpperCase(),
        major: parseInt(beaconRaw[2], 10),
        minor: parseInt(beaconRaw[3], 10),
        rssi: -1,
        accuracy: -1,
        proximity: -1
    };
}

exports.map = map;
},{"alloy":undefined,"alloy/backbone":undefined,"alloy/underscore":undefined}],13:[function(require,module,exports){
'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.Collection = exports.Model = exports.definition = undefined;

var _alloy = require('alloy');

var _alloy2 = _interopRequireDefault(_alloy);

var _underscore = require('alloy/underscore');

var _backbone = require('alloy/backbone');

var _backbone2 = _interopRequireDefault(_backbone);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/* jshint ignore:end */

var model = void 0,
    collection = void 0;

var definition = exports.definition = {
    config: {
        columns: {
            "id": "INTEGER PRIMARY KEY AUTOINCREMENT",
            "UUID": "TEXT",
            "major": "INTEGER",
            "minor": "INTEGER",
            "rssi": "INTEGER",
            "accuracy": "INTEGER",
            "timestamp": "INTEGER"
        },
        adapter: {
            db_name: "sensimity",
            type: "sql",
            collection_name: "BeaconLog",
            idAttribute: "id"
        }
    },
    extendModel: function extendModel(Model) {
        _underscore._.extend(Model.prototype, {});

        return Model;
    },
    extendCollection: function extendCollection(Collection) {
        _underscore._.extend(Collection.prototype, {
            // Extend, override or implement Backbone.Collection

            erase: function erase(args) {
                var self = this;

                var sql = 'DELETE FROM ' + self.config.adapter.collection_name,
                    db = Ti.Database.open(self.config.adapter.db_name);
                db.execute(sql);
                db.close();

                self.fetch();
            }
        });

        return Collection;
    }
};

// Alloy compiles models automatically to this statement. In this case the models not exists in /app/models folder, so this must be fixed by set this statements manually.
exports.Model = model = _alloy2.default.M("BeaconLog", exports.definition, []);
exports.Collection = collection = _alloy2.default.C("BeaconLog", exports.definition, model);
exports.Model = model;
exports.Collection = collection;
},{"alloy":undefined,"alloy/backbone":undefined,"alloy/underscore":undefined}],14:[function(require,module,exports){
'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.Collection = exports.Model = exports.definition = undefined;

var _alloy = require('alloy');

var _alloy2 = _interopRequireDefault(_alloy);

var _underscore = require('alloy/underscore');

var _backbone = require('alloy/backbone');

var _backbone2 = _interopRequireDefault(_backbone);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/* jshint ignore:end */

var model = void 0,
    collection = void 0;

var definition = exports.definition = {
    config: {
        columns: {
            "id": "INTEGER PRIMARY KEY AUTOINCREMENT",
            "UUID": "TEXT",
            "major": "INTEGER",
            "minor": "INTEGER",
            "notifiedDate": "REAL" // datetime not supported by backbonemodels in titanium, so use juliandate (REAL)
        },
        adapter: {
            db_name: "sensimity",
            type: "sql",
            collection_name: "BeaconNotified",
            idAttribute: "id"
        }
    },
    extendModel: function extendModel(Model) {
        _underscore._.extend(Model.prototype, {});

        return Model;
    },
    extendCollection: function extendCollection(Collection) {
        _underscore._.extend(Collection.prototype, {
            // Extend, override or implement Backbone.Collection

            erase: function erase(args) {
                var self = this;

                var sql = 'DELETE FROM ' + self.config.adapter.collection_name,
                    db = Ti.Database.open(self.config.adapter.db_name);
                db.execute(sql);
                db.close();

                self.fetch();
            }
        });

        return Collection;
    }
};

// Alloy compiles models automatically to this statement. In this case the models not exists in /app/models folder, so this must be fixed by set this statements manually.
exports.Model = model = _alloy2.default.M("BeaconNotified", exports.definition, []);
exports.Collection = collection = _alloy2.default.C("BeaconNotified", exports.definition, model);
exports.Model = model;
exports.Collection = collection;
},{"alloy":undefined,"alloy/backbone":undefined,"alloy/underscore":undefined}],15:[function(require,module,exports){
'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.Collection = exports.Model = exports.definition = undefined;

var _alloy = require('alloy');

var _alloy2 = _interopRequireDefault(_alloy);

var _underscore = require('alloy/underscore');

var _backbone = require('alloy/backbone');

var _backbone2 = _interopRequireDefault(_backbone);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/* jshint ignore:end */

var model = void 0,
    collection = void 0;

var definition = exports.definition = {
    config: {
        columns: {
            "id": "INTEGER PRIMARY KEY AUTOINCREMENT",
            "business_rule_id": "INTEGER",
            "beacon_id": "INTEGER",
            "type": "TEXT",
            "interaction_id": "INTEGER",
            "interaction_type": "TEXT",
            "content": "TEXT"
        },
        adapter: {
            db_name: "sensimity",
            type: "sql",
            collection_name: "BusinessRule",
            idAttribute: "id"
        }
    },
    extendModel: function extendModel(Model) {
        _underscore._.extend(Model.prototype, {});

        return Model;
    },
    extendCollection: function extendCollection(Collection) {
        _underscore._.extend(Collection.prototype, {
            // Extend, override or implement Backbone.Collection

            erase: function erase(args) {
                var self = this;

                var sql = 'DELETE FROM ' + self.config.adapter.collection_name,
                    db = Ti.Database.open(self.config.adapter.db_name);
                db.execute(sql);
                db.close();

                self.fetch();
            }
        });

        return Collection;
    }
};

// Alloy compiles models automatically to this statement. In this case the models not exists in /app/models folder, so this must be fixed by set this statements manually.
exports.Model = model = _alloy2.default.M("BusinessRule", exports.definition, []);
exports.Collection = collection = _alloy2.default.C("BusinessRule", exports.definition, model);
exports.Model = model;
exports.Collection = collection;
},{"alloy":undefined,"alloy/backbone":undefined,"alloy/underscore":undefined}],16:[function(require,module,exports){
'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.Collection = exports.Model = exports.definition = undefined;

var _alloy = require('alloy');

var _alloy2 = _interopRequireDefault(_alloy);

var _underscore = require('alloy/underscore');

var _backbone = require('alloy/backbone');

var _backbone2 = _interopRequireDefault(_backbone);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/* jshint ignore:end */

var model = void 0,
    collection = void 0;

var definition = exports.definition = {
    config: {
        columns: {
            "id": "INTEGER",
            "beacon_id": "INTEGER",
            "network_id": "INTEGER",
            "title": "TEXT",
            "description": "TEXT",
            "UUID": "TEXT",
            "major": "INTEGER",
            "minor": "INTEGER",
            "latitude": "REAL",
            "longitude": "REAL",
            "is_geofence": "INTEGER"
        },
        adapter: {
            db_name: "sensimity",
            type: "sql",
            collection_name: "KnownBeacon",
            idAttribute: "id"
        }
    },
    extendModel: function extendModel(Model) {
        _underscore._.extend(Model.prototype, {});

        return Model;
    },
    extendCollection: function extendCollection(Collection) {
        _underscore._.extend(Collection.prototype, {
            // Extend, override or implement Backbone.Collection

            erase: function erase(args) {
                var self = this;

                var sql = 'DELETE FROM ' + self.config.adapter.collection_name,
                    db = Ti.Database.open(self.config.adapter.db_name);
                db.execute(sql);
                db.close();

                self.fetch();
            }
        });

        return Collection;
    }
};

// Alloy compiles models automatically to this statement. In this case the models not exists in /app/models folder, so this must be fixed by set this statements manually.
exports.Model = model = _alloy2.default.M("KnownBeacon", exports.definition, []);
exports.Collection = collection = _alloy2.default.C("KnownBeacon", exports.definition, model);
exports.Model = model;
exports.Collection = collection;
},{"alloy":undefined,"alloy/backbone":undefined,"alloy/underscore":undefined}],17:[function(require,module,exports){
'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});

exports.default = function (runInService) {
    var self = new _base2.default(_beacon2.default, _beaconRegion2.default, _beaconRegionMonitoring2.default);
    self.Beacons = require('com.drtech.altbeacon');
    self.scanPeriods = {
        'proactive': {
            foregroundScanPeriod: 1101,
            foregroundBetweenScanPeriod: 0,
            backgroundScanPeriod: 5001,
            backgroundBetweenScanPeriod: 60001
        },
        'aggressive': {
            foregroundScanPeriod: 1001,
            foregroundBetweenScanPeriod: 0,
            backgroundScanPeriod: 2001,
            backgroundBetweenScanPeriod: 5001
        }
    };

    self.isBLESupported = function () {
        return self.Beacons.isBLESupported();
    };

    self.isBLEEnabled = function (callback) {
        if (!_underscore._.isFunction(callback)) {
            Ti.API.warn('please define a function callback, ble status cannot be retrieved');
            return;
        }
        callback(self.Beacons.checkAvailability());
    };

    // Bind the beaconservice
    self.bindService = function (bindCallback) {
        var handleServiceBind = function handleServiceBind() {
            self.Beacons.removeEventListener("serviceBound", handleServiceBind);
            bindCallback();
        };
        self.Beacons.setAutoRange(true);
        self.Beacons.setRunInService(runInService);
        self.Beacons.addBeaconLayout('m:2-3=0215,i:4-19,i:20-21,i:22-23,p:24-24');
        // Start scanning after binding beaconservice
        self.Beacons.addEventListener("serviceBound", handleServiceBind);
        self.Beacons.bindBeaconService();
    };

    // Stop scanning
    self.stopScanning = function () {
        if (self.Beacons.beaconServiceIsBound()) {
            self.Beacons.stopMonitoringAllRegions();
            self.Beacons.unbindBeaconService();
        }
        self.removeAllEventListeners();
        self.destruct();
    };

    // Add eventlisteners for scanning beacons
    self.addAllEventListeners = function () {
        self.Beacons.addEventListener('beaconProximity', self.beaconFound);
    };

    // Remove eventlisteners when the scanning is stopped
    self.removeAllEventListeners = function () {
        self.Beacons.removeEventListener('beaconProximity', self.beaconFound);
    };

    // Set backgroundmode to save power in background
    self.setBackgroundMode = function (value) {
        self.Beacons.setBackgroundMode(value);
    };

    self.setBehavior = function (period) {
        if (!_underscore._.has(self.scanPeriods, period)) {
            Ti.API.warn('behavior cannot be set. Only values \'proactive\' or \'aggressive\' are applicable');
            return;
        }
        self.Beacons.setScanPeriods(self.scanPeriods[period]);
    };

    return self;
};

var _alloy = require('alloy');

var _alloy2 = _interopRequireDefault(_alloy);

var _underscore = require('alloy/underscore');

var _backbone = require('alloy/backbone');

var _backbone2 = _interopRequireDefault(_backbone);

var _base = require('./../scanners/base');

var _base2 = _interopRequireDefault(_base);

var _beacon = require('./../mapper/altbeacon/beacon');

var _beacon2 = _interopRequireDefault(_beacon);

var _beaconRegion = require('./../mapper/altbeacon/beaconRegion');

var _beaconRegion2 = _interopRequireDefault(_beaconRegion);

var _beaconRegionMonitoring = require('./../mapper/altbeacon/beaconRegionMonitoring');

var _beaconRegionMonitoring2 = _interopRequireDefault(_beaconRegionMonitoring);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
},{"./../mapper/altbeacon/beacon":6,"./../mapper/altbeacon/beaconRegion":7,"./../mapper/altbeacon/beaconRegionMonitoring":8,"./../scanners/base":18,"alloy":undefined,"alloy/backbone":undefined,"alloy/underscore":undefined,"com.drtech.altbeacon":undefined}],18:[function(require,module,exports){
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _alloy = require("alloy");

var _alloy2 = _interopRequireDefault(_alloy);

var _underscore = require("alloy/underscore");

var _backbone = require("alloy/backbone");

var _backbone2 = _interopRequireDefault(_backbone);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/* Compatibility for Ti standalone (without Alloy) */
if (typeof OS_ANDROID === "undefined") {
    var OS_ANDROID = Ti.Platform.name === "android";
    var OS_IOS = Ti.Platform.name === "iPhone OS";
}

/* jshint ignore:end */

/**
 * Abstract BaseScanner. Please use this function as a self object. Add a custom beaconmapper, beaconregionmapper and beaconregionmonitoringmapper.
 * @param beaconMapper Beaconmapper to map a foundbeacon in a beacon who can handled by the beaconhandler
 * @param beaconRegionMapper BeaconRegionMapper to convert a knownbeacon in a beaconregion.
 * @param beaconRegionMonitoringMapper BeaconRegionMonitoringMapper to convert a knownbeacon in a beaconregion which can be monitored.
 * @constructor Use this basescanner as an abstract function. Please set in the child function var self = BaseScanner();
 */
var BaseScanner = function BaseScanner(beaconMapper, beaconRegionMapper, beaconRegionMonitoringMapper) {
    var _this = this;

    var self = this,
        beaconHandler = require('./../handlers/beaconHandler'),
        beaconLog = require('./../service/beaconLog'),
        knownBeaconService = require('./../service/knownBeacons');

    /**
     * Public functions
     */

    /**
     * Initialise the scanner.
     * @param networkIdentifier the identifier of the Sensimity-network which must be scanned
     */
    this.init = function (networkIdentifier) {
        if (_underscore._.isUndefined(networkIdentifier)) {
            Ti.API.warn('Network identifier is undefined. Scanner not initialized');
            return;
        }

        self.networkId = networkIdentifier;

        if (!OS_IOS) {
            self.prepareForScanning();
            return;
        }

        self.handleiOSLocationPermissions();
    };

    this.prepareForScanning = function () {
        beaconHandler.init();
        beaconLog.init();
        self.setBeaconRegions([]);
        if (OS_IOS && Ti.App.arguments.launchOptionsLocationKey) {
            // Do not refresh beacons if the app has been started based on an enter/exited region event
            return;
        }
        knownBeaconService.refreshBeacons([self.networkId]);
    };

    this.isOldTiVersion = function () {
        var version = Ti.version.split(".");
        if (version[0] < 5) {
            // Version < 5
            return true;
        }
        return version[0] === 5 && version[1] === 0; // Version 5.0.*
    };

    this.handleiOSLocationPermissions = function () {
        // Handle iOS
        var permissionType = Ti.Geolocation.AUTHORIZATION_ALWAYS;
        if (self.isOldTiVersion()) {
            // Version 5.0.*
            // BC: request permission the old way for Titanium < 5.0
            Ti.Geolocation.requestAuthorization(permissionType);
            self.prepareForScanning();
            return;
        }

        if (Ti.Geolocation.hasLocationPermissions(permissionType)) {
            self.prepareForScanning();
            return;
        }

        // Request permission and wait for success
        Ti.Geolocation.requestLocationPermissions(permissionType, function (res) {
            if (res.success) {
                self.prepareForScanning();
            }
        });
    };

    /**
     * Setter for the beaconRegions which will be scanned
     * @param beaconRegions The setting beaconRegions
     */
    this.setBeaconRegions = function (beaconRegions) {
        return self.beaconRegions = beaconRegions;
    };

    /**
     * Start scanning of beacons in setting beaconId
     */
    this.startScanning = function () {
        return self.bindService(_this.startScanningAfterBinding);
    };

    this.startScanningAfterBinding = function () {
        var knownBeacons = knownBeaconService.getKnownBeacons(self.networkId);
        var bleBeacons = knownBeacons.filter(function (knownBeacon) {
            return !knownBeacon.get('is_geofence');
        });
        var geofenceBeacons = knownBeacons.filter(function (knownBeacon) {
            return knownBeacon.get('is_geofence');
        });
        startScanningOfKnownBeacons(bleBeacons);
        self.addAllEventListeners();
        self.startScanningGeofences(geofenceBeacons);
    };

    this.startScanningGeofences = function (geofenceBeacons) {
        // fallback for locations who don't have physical-BLE-Beacons
        if (geofenceBeacons.length === 0) {
            return;
        }
        var pathsenseLib = require('./../scanners/pathsense');
        pathsenseLib.init();
        pathsenseLib.stopMonitoring();
        geofenceBeacons.forEach(function (beacon) {
            var identifier = beacon.get('beacon_id') + "|" + beacon.get('UUID') + "|" + beacon.get('major') + "|" + beacon.get('minor');
            pathsenseLib.startMonitoring({
                identifier: identifier,
                latitude: beacon.get('latitude'),
                longitude: beacon.get('longitude'),
                radius: 100
            });
        });
    };

    /**
     * Map a found beacon and start the beaconHandler
     * @param beaconRaw A raw beacon found by the beaconscanner
     */
    this.beaconFound = function (beaconRaw) {
        if (_underscore._.isUndefined(beaconRaw.rssi)) {
            return;
        }
        var rssi = parseInt(beaconRaw.rssi);
        if (rssi === 0) {
            return;
        }
        var beacon = beaconMapper.map(beaconRaw);
        beaconLog.insertBeaconLog(beacon);
        beaconHandler.handle(beacon);
    };

    /**
     * Destruct the scanner
     */
    this.destruct = function () {
        return self.beaconRegions = [];
    };

    /**
     * Private functions
     */

    // Start the scanning of found beacons
    function startScanningOfKnownBeacons(knownBeacons) {
        knownBeacons.forEach(function (knownBeacon) {
            if (knownBeacon.get('UUID') === null) {
                startScanningOfBeacon(knownBeacon);
            }
        });
    }

    /**
     * Start scanning of a beacon
     * @param knownBeacon The beacon which will be scanning
     */
    function startScanningOfBeacon(knownBeacon) {
        // Reduce scanned beaconregions
        if (isBeaconRegionScanning(knownBeacon)) {
            return;
        }

        var beaconRegionMonitoring = beaconRegionMonitoringMapper.map(knownBeacon);
        var beaconRegion = beaconRegionMapper.map(knownBeacon);
        self.Beacons.startMonitoringForRegion(beaconRegionMonitoring);
        self.beaconRegions.push(beaconRegion);
    }

    /**
     * If check beaconregion is already scanning
     * @param knownBeacon Check this beacon scanned now
     * @returns false if beaconRegion is scanning, true if not scanning
     */
    function isBeaconRegionScanning(knownBeacon) {
        // Check beaconregion already scanning
        return self.beaconRegions.some(function (region) {
            return region.uuid.toUpperCase() === knownBeacon.get('UUID').toUpperCase();
        });
    }
};

exports.default = BaseScanner;
},{"./../handlers/beaconHandler":5,"./../scanners/pathsense":20,"./../service/beaconLog":23,"./../service/knownBeacons":25,"alloy":undefined,"alloy/backbone":undefined,"alloy/underscore":undefined}],19:[function(require,module,exports){
'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});

exports.default = function () {
    // set self = basescanner to use this function as an abstract function for the beuckmanfunction
    var self = new _base2.default(_beacon2.default, _beaconRegion2.default, _beaconRegionMonitoring2.default);
    self.Beacons = require('org.beuckman.tibeacons');

    self.isBLESupported = function () {
        return self.Beacons.isBLESupported();
    };

    self.isBLEEnabled = function (callback) {
        if (!_underscore._.isFunction(callback)) {
            Ti.API.warn('please define a function callback, ble status cannot be retrieved');
            return;
        }
        var handleBleStatus = function handleBleStatus(e) {
            // Useless status See https://github.com/jbeuckm/TiBeacons/issues/24
            if (e.status === 'unknown') {
                return;
            }
            self.Beacons.removeEventListener('bluetoothStatus', handleBleStatus);
            if (e.status === 'on') {
                callback(true);
            } else {
                callback(false);
            }
        };
        self.Beacons.addEventListener('bluetoothStatus', handleBleStatus);

        self.Beacons.requestBluetoothStatus();
    };

    // Bindservice function is required in from the Basescanner, but Beuckman contains no bindoption
    self.bindService = function (bindCallback) {
        return bindCallback();
    };

    // Start ranging beacons when a beaconregion is detected
    self.enterRegion = function (param) {
        return self.Beacons.startRangingForBeacons(param);
    };

    // Stop ranging beacons for a region when a beaconregion is exited
    self.exitRegion = function (param) {
        return self.Beacons.stopRangingForBeacons(param);
    };

    // Call beaconfound for every found beacon and handle the found beacons
    self.beaconRangerHandler = function (param) {
        param.beacons.forEach(function (beacon) {
            self.beaconFound(beacon);
        });
    };

    self.regionState = function (e) {
        if (e.regionState === 'inside') {
            self.Beacons.startRangingForBeacons({
                uuid: e.uuid,
                identifier: e.identifier
            });
        } else if (e.regionState === 'outside') {
            self.Beacons.stopRangingForBeacons({
                uuid: e.uuid,
                identifier: e.identifier
            });
        }
    };

    // override stopscanning
    self.stopScanning = function () {
        self.removeAllEventListeners();
        self.Beacons.stopMonitoringAllRegions();
        self.Beacons.stopRangingForAllBeacons();
        self.destruct();
    };

    // Add eventlisteners, called by startingscan in Basescanner
    self.addAllEventListeners = function () {
        self.Beacons.addEventListener('beaconRanges', self.beaconRangerHandler);
        self.Beacons.addEventListener('determinedRegionState', self.regionState);
    };

    // Remove eventlisteners on stop scanning
    self.removeAllEventListeners = function () {
        self.Beacons.removeEventListener('beaconRanges', self.beaconRangerHandler);
        self.Beacons.removeEventListener('determinedRegionState', self.regionState);
    };

    return self;
};

var _alloy = require('alloy');

var _alloy2 = _interopRequireDefault(_alloy);

var _underscore = require('alloy/underscore');

var _backbone = require('alloy/backbone');

var _backbone2 = _interopRequireDefault(_backbone);

var _base = require('./../scanners/base');

var _base2 = _interopRequireDefault(_base);

var _beacon = require('./../mapper/beuckman/beacon');

var _beacon2 = _interopRequireDefault(_beacon);

var _beaconRegion = require('./../mapper/beuckman/beaconRegion');

var _beaconRegion2 = _interopRequireDefault(_beaconRegion);

var _beaconRegionMonitoring = require('./../mapper/beuckman/beaconRegionMonitoring');

var _beaconRegionMonitoring2 = _interopRequireDefault(_beaconRegionMonitoring);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
},{"./../mapper/beuckman/beacon":9,"./../mapper/beuckman/beaconRegion":10,"./../mapper/beuckman/beaconRegionMonitoring":11,"./../scanners/base":18,"alloy":undefined,"alloy/backbone":undefined,"alloy/underscore":undefined,"org.beuckman.tibeacons":undefined}],20:[function(require,module,exports){
'use strict';

Object.defineProperty(exports, "__esModule", {
	value: true
});

var _comSensimityTi = require('com.sensimity.ti.pathsense');

var _comSensimityTi2 = _interopRequireDefault(_comSensimityTi);

var _beacon = require('./../mapper/pathsense/beacon');

var _beacon2 = _interopRequireDefault(_beacon);

var _beaconHandler = require('./../handlers/beaconHandler');

var _beaconHandler2 = _interopRequireDefault(_beaconHandler);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var enteredRegion = function enteredRegion(geofenceRegion) {
	var beacon = _beacon2.default.map(geofenceRegion);
	_beaconHandler2.default.handle(beacon);
};

var init = function init() {
	return _comSensimityTi2.default.addEventListener('enteredRegion', enteredRegion);
};

var destruct = function destruct() {
	return _comSensimityTi2.default.removeEventListener('enteredRegion', enteredRegion);
};

var startMonitoring = function startMonitoring(region) {
	return _comSensimityTi2.default.startMonitoringForRegion(region);
};

var stopMonitoring = function stopMonitoring() {
	return _comSensimityTi2.default.stopMonitoringAllRegions();
};

exports.default = {
	init: init,
	destruct: destruct,
	startMonitoring: startMonitoring,
	stopMonitoring: stopMonitoring
};
},{"./../handlers/beaconHandler":5,"./../mapper/pathsense/beacon":12,"com.sensimity.ti.pathsense":undefined}],21:[function(require,module,exports){
'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.getKnownBeacons = exports.isBLEEnabled = exports.isBLESupported = exports.sensimityClient = exports.runService = exports.resume = exports.pause = exports.stop = exports.start = undefined;

var _alloy = require('alloy');

var _alloy2 = _interopRequireDefault(_alloy);

var _underscore = require('alloy/underscore');

var _backbone = require('alloy/backbone');

var _backbone2 = _interopRequireDefault(_backbone);

var _client = require('./client/client');

var _client2 = _interopRequireDefault(_client);

var _knownBeacons = require('./service/knownBeacons');

var _knownBeacons2 = _interopRequireDefault(_knownBeacons);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/* Compatibility for Ti standalone (without Alloy) */
if (typeof OS_ANDROID === "undefined") {
    var OS_ANDROID = Ti.Platform.name === "android";
    var OS_IOS = Ti.Platform.name === "iPhone OS";
}

if (_underscore._.isUndefined(_alloy2.default.Globals.sensimityEvent)) {
    var dispatcher = require('./dispatcher');
    _alloy2.default.Globals.sensimityEvent = dispatcher;
}

/**
 * Initialize the scanner and start scanning on added network identifier
 * @param options {network_id: <network identifier to scan beacons>}
 * @param callback Callback to inform about the start of sensimity {success: <bool>, message: <string>}
 */
function start(options, callback) {
    // Only start Sensimity when bluetooth is enabled
    isBLEEnabled(function (value) {
        if (!value) {
            var message = 'Sensimity scan not started because BLE not enabled';
            Ti.API.warn(message);
            if (_underscore._.isFunction(callback)) {
                callback({
                    success: false,
                    message: message
                });
            }
            return;
        }

        if (_underscore._.isUndefined(_alloy2.default.Globals.sensimityScanner) === false) {
            Ti.API.warn('Scanner already defined, please destruct first before start scanning');
        } else {
            _alloy2.default.Globals.sensimityScanner = createScanner(options);
            initScannerAndStartScanning(options);
        }
        if (_underscore._.isFunction(callback)) {
            callback({
                success: true,
                message: 'Sensimity successfully started'
            });
        }
    });
}

/**
 * Stop scanning
 */
function stop() {
    _alloy2.default.Globals.sensimityEvent["default"].off('sensimity:beaconsRefreshed', restartScanner);
    if (!_underscore._.isUndefined(_alloy2.default.Globals.sensimityScanner)) {
        _alloy2.default.Globals.sensimityScanner.stopScanning();
    }
    _alloy2.default.Globals.sensimityScanner = undefined;
}

function pause() {
    if (!OS_ANDROID) {
        Ti.API.warn('sensimity pause not needed on other platforms than Android');
        return;
    }

    if (_underscore._.isUndefined(_alloy2.default.Globals.sensimityScanner)) {
        Ti.API.warn('Scanner not initialized, please first initialize the sensimity library');
        return;
    }

    _alloy2.default.Globals.sensimityScanner.setBackgroundMode(true);
}

function resume() {
    if (!OS_ANDROID) {
        Ti.API.warn('sensimity resume not needed on other platforms than Android');
        return;
    }

    if (_underscore._.isUndefined(_alloy2.default.Globals.sensimityScanner)) {
        Ti.API.warn('Scanner not initialized, please first initialize the sensimity library');
        return;
    }

    _alloy2.default.Globals.sensimityScanner.setBackgroundMode(false);
}

/**
 * Start background intent for Android
 * @param callback Callback to inform about the start of sensimity {success: <bool>, message: <string>}
 */
function runService(options, callback) {
    // Only start Sensimity when bluetooth is enabled
    isBLEEnabled(function (value) {
        if (!value) {
            var message = 'Sensimity scan not started because BLE not enabled';
            Ti.API.warn(message);
            if (_underscore._.isFunction(callback)) {
                callback({
                    success: false,
                    message: message
                });
            }
            return;
        }

        if (!OS_ANDROID || _underscore._.isUndefined(_alloy2.default.CFG.sensimity.backgroundService)) {
            return;
        }

        var intent = Ti.Android.createServiceIntent({
            url: _alloy2.default.CFG.sensimity.backgroundService,
            startMode: Ti.Android.START_REDELIVER_INTENT
        });
        if (_underscore._.isNumber(options.networkId)) {
            intent.putExtra('networkId', options.networkId);
        }
        if (Ti.Android.isServiceRunning(intent)) {
            Ti.Android.stopService(intent);
        }
        Ti.Android.startService(intent);
        if (_underscore._.isFunction(callback)) {
            callback({
                success: true,
                message: 'Sensimity successfully started in a Android service'
            });
        }
    });
}

function isBLESupported() {
    var scanner = void 0;
    if (OS_ANDROID) {
        scanner = require('./scanners/altbeacon')();
    } else if (OS_IOS) {
        scanner = require('./scanners/beuckman')();
    }
    return scanner.isBLESupported();
}

function isBLEEnabled(callback) {
    var scanner = void 0;
    if (OS_ANDROID) {
        scanner = require('./scanners/altbeacon')();
    } else if (OS_IOS) {
        scanner = require('./scanners/beuckman')();
    }
    scanner.isBLEEnabled(callback);
}

var getKnownBeacons = function getKnownBeacons() {
    return _knownBeacons2.default.getKnownBeacons();
};
exports.start = start;
exports.stop = stop;
exports.pause = pause;
exports.resume = resume;
exports.runService = runService;
exports.sensimityClient = _client2.default;
exports.isBLESupported = isBLESupported;
exports.isBLEEnabled = isBLEEnabled;
exports.getKnownBeacons = getKnownBeacons;

// Create an scanner, specific for the running platform

function createScanner(options) {
    if (OS_ANDROID) {
        var runInService = false;
        if (_underscore._.isBoolean(options.runInService)) {
            runInService = options.runInService;
        }
        // Android, use the altbeaconscanner to scan iBeacons
        var altbeaconScanner = require('./scanners/altbeacon');
        return altbeaconScanner(runInService);
    } else if (OS_IOS) {
        // iOS, use the beuckmanscanner to scan iBeacons
        var beuckmanScanner = require('./scanners/beuckman');
        return beuckmanScanner();
    }
}

// Initialize the sensimityscanner and start scanning on added networkID
function initScannerAndStartScanning(options) {
    if (!_underscore._.has(options, 'networkId') || options.networkId === null) {
        Ti.API.warn('Please add a networkId, scanner not started');
        return;
    }
    _alloy2.default.Globals.sensimityScanner.init(options.networkId);
    if (OS_ANDROID && _underscore._.has(options, 'behavior')) {
        _alloy2.default.Globals.sensimityScanner.setBehavior(options.behavior);
    }
    _alloy2.default.Globals.sensimityScanner.startScanning();
    _alloy2.default.Globals.sensimityEvent["default"].on('sensimity:beaconsRefreshed', restartScanner);
}

// After refreshing beacons, restart the scanner
function restartScanner() {
    if (!_underscore._.isUndefined(_alloy2.default.Globals.sensimityScanner)) {
        _alloy2.default.Globals.sensimityScanner.stopScanning();
        _alloy2.default.Globals.sensimityScanner.startScanning();
    }
}
},{"./client/client":2,"./dispatcher":4,"./scanners/altbeacon":17,"./scanners/beuckman":19,"./service/knownBeacons":25,"alloy":undefined,"alloy/backbone":undefined,"alloy/underscore":undefined}],22:[function(require,module,exports){
'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _alloy = require('alloy');

var _alloy2 = _interopRequireDefault(_alloy);

var _underscore = require('alloy/underscore');

var _backbone = require('alloy/backbone');

var _backbone2 = _interopRequireDefault(_backbone);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/* jshint ignore:end */

/**
 * Public functions
 */

/**
 * Use an Model defined in the sensimity library
 * @param name The name of the model
 * @param args Arguments for creating a Backbone model
 */
function createSensimityModel(name, args) {
    switch (name) {
        case "BeaconLog":
            return new (require("./../models/BeaconLog").Model)(args);
        case "BeaconNotified":
            return new (require("./../models/BeaconNotified").Model)(args);
        case "BusinessRule":
            return new (require("./../models/BusinessRule").Model)(args);
        default:
            return new (require("./../models/KnownBeacon").Model)(args);
    }
}

/**
 * Use an Collection defined in the sensimity library
 * @param name The name of the model-collection
 * @param args Arguments for creating a Backbone collection
 */
function createSensimityCollection(name, args) {
    switch (name) {
        case "BeaconLog":
            return new (require("./../models/BeaconLog").Collection)(args);
        case "BeaconNotified":
            return new (require("./../models/BeaconNotified").Collection)(args);
        case "BusinessRule":
            return new (require("./../models/BusinessRule").Collection)(args);
        default:
            return new (require("./../models/KnownBeacon").Collection)(args);
    }
}

exports.default = { createSensimityModel: createSensimityModel, createSensimityCollection: createSensimityCollection };
},{"./../models/BeaconLog":13,"./../models/BeaconNotified":14,"./../models/BusinessRule":15,"./../models/KnownBeacon":16,"alloy":undefined,"alloy/backbone":undefined,"alloy/underscore":undefined}],23:[function(require,module,exports){
'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _alloy = require('alloy');

var _alloy2 = _interopRequireDefault(_alloy);

var _underscore = require('alloy/underscore');

var _backbone = require('alloy/backbone');

var _backbone2 = _interopRequireDefault(_backbone);

var _client = require('./../client/client');

var _client2 = _interopRequireDefault(_client);

var _base = require('./../service/base');

var _base2 = _interopRequireDefault(_base);

var _ti = require('ti.mely');

var _ti2 = _interopRequireDefault(_ti);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/**
 * Public functions
 */

/**
 * Initialize the beaconlogservice. At initialization the beaconlogs earlier retrieved will be send to Sensimity.
 */
function init() {
    // Send beaconlogs every 30 seconds
    var timer = _ti2.default.createTimer();
    timer.start({
        interval: 30000
    });
    timer.addEventListener('onIntervalChange', sendBeaconLogs);
    sendBeaconLogs();
}

/**
 * Create and save a new beaconlog to send in the future to sensimitys
 * @param beacon A beacon recieved by the beaconscanner
 */
function insertBeaconLog(beacon) {
    beacon.timestamp = Math.round(new Date().getTime() / 1000);
    var beaconLog = _base2.default.createSensimityModel('BeaconLog', beacon);
    beaconLog.save();
}

exports.default = { init: init, insertBeaconLog: insertBeaconLog };

/**
 * Send the beacons to Sensimity
 */

function sendBeaconLogs() {
    if (!Ti.Network.getOnline()) {
        return;
    }

    var library = _base2.default.createSensimityCollection('BeaconLog');
    // Send the beaconlogs to the SensimityAPI after fetching from the local database. Only send when beaconlogs are available.
    var success = function success(beaconLogs) {
        // Send beaconlogs only if exists
        if (beaconLogs.length !== 0) {
            _client2.default.sendScanResults(JSON.parse(JSON.stringify(createBeaconLogsCollection(beaconLogs))), destroyBeaconLogs);
        }
    };
    library.fetch({
        success: success
    });
}

/**
 * Create an beaconlogs collection. A instanceref is required to send beaconlogs.
 * @param beaconLogs The beaconlogs which will be send to the SensimityAPI.
 * @returns {{instance_ref: (exports.sensimity.instanceRef|*), device: {device_id: String, model: String, operating_system: String, version: String}, beaconLogs: *}}
 */
function createBeaconLogsCollection(beaconLogs) {
    var instanceRef = _alloy2.default.CFG.sensimity.instanceRef;
    return {
        instance_ref: instanceRef,
        device: {
            device_id: Ti.Platform.id,
            model: Ti.Platform.model,
            operating_system: Ti.Platform.osname,
            version: Ti.Platform.version
        },
        beaconLogs: beaconLogs
    };
}

/**
 * Destroy the beaconlogs from local database
 */
function destroyBeaconLogs() {
    _base2.default.createSensimityCollection('BeaconLog').erase();
}
},{"./../client/client":2,"./../service/base":22,"alloy":undefined,"alloy/backbone":undefined,"alloy/underscore":undefined,"ti.mely":undefined}],24:[function(require,module,exports){
'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _alloy = require('alloy');

var _alloy2 = _interopRequireDefault(_alloy);

var _underscore = require('alloy/underscore');

var _backbone = require('alloy/backbone');

var _backbone2 = _interopRequireDefault(_backbone);

var _client = require('./../client/client');

var _client2 = _interopRequireDefault(_client);

var _base = require('./../service/base');

var _base2 = _interopRequireDefault(_base);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/**
 * Public functions
 */

/*******
 * Function to refresh the beacons from Sensimity of a known beacon
 * @param {Object} knownBeacon find the business rules of this beacon
 */
function fetchBusinessRules(knownBeacon) {
    _client2.default.getBusinessRules(knownBeacon.get('network_id'), knownBeacon.get('beacon_id'), function (data) {
        if (_underscore._.isEmpty(data._embedded.business_rule)) {
            return;
        }

        var rawBusinessRules = data._embedded.business_rule;
        rawBusinessRules.forEach(function (businessruleRaw) {
            saveFetchedBusinessRules(businessruleRaw);
        });
    });
}

/****
 * Function to get all the business rules already saved on the phone
 * @param knownBeacon knownBeacon Get the business rules of this beacon
 */
function getBusinessRules(knownBeacon) {
    var library = _base2.default.createSensimityCollection('BusinessRule');
    library.fetch();
    return library.where({ beacon_id: knownBeacon.get('beacon_id') });
}

exports.default = { getBusinessRules: getBusinessRules, fetchBusinessRules: fetchBusinessRules };

/**
 * Private functions
 */

/******
 * Function to save all the business rules fetched at the fetchSingleBusinessRule function
 * @param {Object} data retrieved raw business rule data
 */

function saveFetchedBusinessRules(data) {
    var existingBusinessRule = findExistingBusinessRule(data.business_rule_id);
    var businessRule = void 0;
    if (_underscore._.isEmpty(existingBusinessRule)) {
        // CREATE NEW Business rule
        businessRule = createNewBusinessRuleItem(data);
    } else {
        // Override existing business rule
        businessRule = setNewDataInExistingBusinessRule(existingBusinessRule, data);
    }
    businessRule.save();
}

/**
 * Create a new businessrule item from the data received from Sensimity
 * @param data The businessrule received from Sensimitys
 * @returns BusinessRule a created businessrule
 */
function createNewBusinessRuleItem(data) {
    return _base2.default.createSensimityModel('BusinessRule', {
        business_rule_id: data.business_rule_id,
        beacon_id: data.beacon_id,
        type: data.business_rule_type,
        interaction_id: data.interaction_id,
        interaction_type: data.interaction_type,
        content: data.content
    });
}

/**
 * Set new information retrieved from Sensimity in de Businessrule
 * @param existingBusinessRule The businessrule earlier retrieved from Sensimity
 * @param data The new data
 */
function setNewDataInExistingBusinessRule(existingBusinessRule, data) {
    // Override existing business rule
    existingBusinessRule.set('beacon_id', data.beacon_id);
    existingBusinessRule.set('type', data.business_rule_type);
    existingBusinessRule.set('interaction_id', data.interaction_id);
    existingBusinessRule.set('interaction_type', data.interaction_type);
    existingBusinessRule.set('content', data.content);
    return existingBusinessRule;
}

/*****
 * Find a business rule based on businessrule Id
 * @param id businessRuleId
 */
function findExistingBusinessRule(businessRuleId) {
    var library = _base2.default.createSensimityCollection('BusinessRule');
    library.fetch();
    var businessRule = library.where({ business_rule_id: businessRuleId });
    if (_underscore._.isEmpty(businessRule)) {
        return businessRule;
    }

    return _underscore._.first(businessRule);
}
},{"./../client/client":2,"./../service/base":22,"alloy":undefined,"alloy/backbone":undefined,"alloy/underscore":undefined}],25:[function(require,module,exports){
'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _alloy = require('alloy');

var _alloy2 = _interopRequireDefault(_alloy);

var _underscore = require('alloy/underscore');

var _backbone = require('alloy/backbone');

var _backbone2 = _interopRequireDefault(_backbone);

var _client = require('./../client/client');

var _client2 = _interopRequireDefault(_client);

var _base = require('./../service/base');

var _base2 = _interopRequireDefault(_base);

var _businessRule = require('./../service/businessRule');

var _businessRule2 = _interopRequireDefault(_businessRule);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _toConsumableArray(arr) { if (Array.isArray(arr)) { for (var i = 0, arr2 = Array(arr.length); i < arr.length; i++) { arr2[i] = arr[i]; } return arr2; } else { return Array.from(arr); } }

/**
 * Function to refresh the beacons from Sensimity
 * @param networkIds The network identifiers which must be refreshed
 */
function refreshBeacons(networkIds) {
    if (!Ti.Network.getOnline()) {
        return;
    }

    var uniqNetworkIds = [].concat(_toConsumableArray(new Set(networkIds)));
    uniqNetworkIds.forEach(function (id) {
        var library = _base2.default.createSensimityCollection('KnownBeacon');
        library.erase();
        _client2.default.getBeacons(id, handleSuccessfullFetchingBeacons);
    });
}

/*****
 * Find a beacon based on UUID, major and minor identifier
 * @param String UUID Beacon UUID
 * @param int major Beacon major id
 * @param int minor Beacon minor id
 */
function findKnownBeacon(UUID, major, minor) {
    var library = _base2.default.createSensimityCollection('KnownBeacon');
    library.fetch();
    var knownBeacons = library.where({
        UUID: UUID,
        major: major,
        minor: minor
    });
    if (_underscore._.isEmpty(knownBeacons)) {
        return knownBeacons;
    } else {
        return _underscore._.first(knownBeacons);
    }
}

/*****
 * Retrieve knownbeacons of a network
 * @param networkId The network identifier of the beacons who searching for
 */
function getKnownBeacons(networkId) {
    var library = _base2.default.createSensimityCollection('KnownBeacon');
    library.reset();
    library.fetch();
    var knownBeaconsOfNetworkId = library.where({ network_id: networkId });
    return knownBeaconsOfNetworkId;
}

exports.default = { refreshBeacons: refreshBeacons, findKnownBeacon: findKnownBeacon, getKnownBeacons: getKnownBeacons };

// When the beacons successfull received from Sensimity, save local and trigger the whole system to let the system know the beacons refreshed

function handleSuccessfullFetchingBeacons(data) {
    // Handle only fetching if data contains beacons.
    if (_underscore._.isUndefined(data._embedded) || _underscore._.isEmpty(data._embedded)) {
        return;
    }

    var rawData = data._embedded.beacon;
    saveNewBeacons(rawData);

    // Let the whole applicatie know that the beacons are refreshed
    _alloy2.default.Globals.sensimityEvent.trigger('sensimity:beaconsRefreshed');
}

// Save all new beacons
function saveNewBeacons(beaconArray) {
    var library = getEarlierSavedKnownBeacons();
    beaconArray.forEach(function (beacon) {
        var checkBeaconAlreadySaved = library.where({
            beacon_id: beacon.beacon_id
        });
        if (!_underscore._.isEmpty(checkBeaconAlreadySaved)) {
            return;
        }

        beacon.UUID = beacon.uuid_beacon.toUpperCase();
        beacon.is_geofence = !_underscore._.isUndefined(beacon.is_geofence) ? beacon.is_geofence : false;
        var sensimityKnownBeacon = _base2.default.createSensimityModel('KnownBeacon', beacon);
        sensimityKnownBeacon.save();

        // Geofences don't contain business rules, so don't fetch them
        if (!sensimityKnownBeacon.get('is_geofence')) {
            return;
        }
        // Also refetch all existing business rules
        _businessRule2.default.fetchBusinessRules(sensimityKnownBeacon);
    });
}

// Get the beacons earlier retrieved from Sensimity
function getEarlierSavedKnownBeacons() {
    var library = _base2.default.createSensimityCollection('KnownBeacon');
    library.reset();
    library.fetch();
    return library;
}
},{"./../client/client":2,"./../service/base":22,"./../service/businessRule":24,"alloy":undefined,"alloy/backbone":undefined,"alloy/underscore":undefined}]},{},[1])(1)
});